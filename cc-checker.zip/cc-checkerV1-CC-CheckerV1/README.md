# cc-checkerV1
Credit Card Checker Stripe Charger 
![PHP](https://img.shields.io/badge/language-PHP-blue.svg)
![BANDITCODING](https://img.shields.io/badge/Team-Banditcoding-green)
![AUTHOR](https://img.shields.io/badge/Author-Zlaxtert-orange)

## Install on desktop : 
- Install XAMPP
- Added environment variable system path => C:\xampp\php
- download the script and save it in your folder
- open CMD and running

## Install on android (Termux)
    $ pkg install git -y
    $ pkg install php -y
    $ git clone https://github.com/Zlaxtert/cc-checkerV1
    $ cd cc-checkerV1
    $ php cc.php

## Screenshot
<img src="img/bg.jpg">

